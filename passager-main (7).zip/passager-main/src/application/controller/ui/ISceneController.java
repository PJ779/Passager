package application.controller.ui;

public interface ISceneController {
    default void onSceneEnter() {
    }
}
